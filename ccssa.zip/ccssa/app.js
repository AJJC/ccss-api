const express = require('express')
const path = require('path')
const cookieParser = require('cookie-parser')
const logger = require('morgan')
const claudia = require('claudia')
const indexRouter = require('./routes/index')
const usersRouter = require('./routes/users')

const serviciosRouter = require('./routes/servicios')
const rolesRouter = require('./routes/roles')

const usuariosRouter = require('./routes/usuarios')
const fichasRouter = require('./routes/fichas')
const verificacionRouter = require('./routes/verificacion.js')

const app = express()
const sql = require('mssql')

app.use(logger('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, 'public')))


app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use('/', indexRouter)
app.use('/users', usersRouter)

async function connect () {
  const config = {
    Uid: 'ATECA',
    Pwd: 'ALFREDO_123',
    Database: 'ATECA_BD',
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    },
    Driver:'{ODBC Driver 13 for SQL Server}',
    Server:'tcp:ateca.database.windows.net,1433',
    Encrypt:'yes',
    TrustServerCertificate:'no',
    ConnectionTimeout:30
  }
  try {
    await sql.connect('mssql://ATECA:ALFREDO_123@ateca.database.windows.net/ATECA_BD?encrypt=true')
    // const result = await sql.query`select * from BitacoraUsuario`
    // console.dir(result)
  } catch (err) {
    console.log(err)
  }
}




connect()

app.use('/serviciosAPI', serviciosRouter)
app.use('/rolesAPI', rolesRouter)

app.use('/usuariosAPI', usuariosRouter)
app.use('/fichasAPI', fichasRouter)
app.use('/verificacionAPI', verificacionRouter)


module.exports = app
