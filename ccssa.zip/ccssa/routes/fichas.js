var express = require('express')
var router = express.Router()
const sql = require('mssql')

/* GET home page. */
router.get('/', async function (req, res, next) {
  const result = await sql.query`select * from Fichas`
  res.json(result).end()
})
  
/* Insert Ficha desde Android */
router.post('/', async function (req, res, next) {
  const { id_servicio,codigoFicha,fecha,atendido,llamado,agendado,correo,nombre,cadenaServicio,tipoFicha,id_usuario } = req.body
  const result = await sql.query`insert into Fichas (id_servicio,codigoFicha,fecha,atendido,llamado,agendado,tipoFicha,id_usuario) values (${id_servicio},
    ${codigoFicha},${fecha},${atendido},${llamado},${agendado},${tipoFicha},${id_usuario})`

    var nodemailer = require('nodemailer')

    let transporter = nodemailer.createTransport({
      service: 'gmail',
      secure: false,
      port: 25,
      auth: {
          user: 'atecaccss2019@gmail.com',
          pass: 'aljica98'
      },
      tls:{
        rejectUnauthorized: false
      }
    })
    
    let HelperOptions = {
      from: '"ATECA" <atecaccss2019@gmail.com',
      to: correo,
      subject: 'Información de Ficha',
      text: 'Saludos '+nombre+',\nUsted acaba de agregar una ficha desde la aplicacion móvil de ATECA\nInformación adjunta:\n'+
      'Servicio: '+cadenaServicio+'\nCodigo de la ficha: '+codigoFicha+'\nFecha: '+fecha+'\n'+agendado+'\nFavor estar presente 15 minutos antes'+
      ' de la hora de atención de su ficha.\n\nGracias por utilizar nuestros servicios,favor no responder este correo\nATECA'
    }
    
    transporter.sendMail(HelperOptions, (error,info) => {
      if(error){
        return console.log(error)
      }
      console.log("The message was sent")
      console.log(info)
    })


  res.json(result).end()
})

router.post('/predet', async function (req, res, next) {
  const { id_servicio,codigoFicha,fecha,atendido,llamado,tipoFicha,id_usuario } = req.body
  const result = await sql.query`insert into Fichas (id_servicio,codigoFicha,fecha,atendido,llamado,tipoFicha,id_usuario) values 
  (${id_servicio},${codigoFicha},${fecha},${atendido},${llamado},${tipoFicha},${id_usuario})`

  res.json(result).end()
})


module.exports = router