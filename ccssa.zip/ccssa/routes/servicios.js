var express = require('express')
var router = express.Router()
const sql = require('mssql')

/* GET home page. */
router.get('/', async function (req, res, next) {
  const result = await sql.query`select * from Servicios`
  res.json(result).end()
})

/* Insert Servicio */
router.post('/', async function (req, res, next) {
  const { nombre, estado, codigoServicio } = req.body
  const result = await sql.query`insert into Servicios(nombre, estado, codigoServicio) values (${nombre},${estado},${codigoServicio})`
  res.json(result).end()
})



/* Update Servicio */
router.put('/', async function (req, res, next) {
  const { nombre, id, estado, codigoServicio } = req.body
  const result = await sql.query`update Servicios set nombre = ${nombre}, estado = ${estado}, 
  codigoServicio = ${codigoServicio} where ID_servicio = ${id}`
    res.json(result).end()
})



module.exports = router
