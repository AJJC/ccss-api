var express = require('express')
var router = express.Router()
const sql = require('mssql')

/* GET home page. */
router.get('/', async function (req, res, next) {
  const result = await sql.query`select * from Roles`
  res.json(result).end()
})
  
/* Insert Rol */
router.post('/', async function (req, res, next) {
  const { nombre, estado } = req.body
  const result = await sql.query`insert into Roles (nombre, estado) values (${nombre},${estado})`
  res.json(result).end()
})

/* Update Rol */
router.put('/', async function (req, res, next) {
  const { nombre, id, estado } = req.body
  const result = await sql.query`update Roles set nombre = ${nombre}, estado = ${estado} where ID_rol = ${id}`
  res.json(result).end()
})

module.exports = router