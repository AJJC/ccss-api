var express = require('express')
var router = express.Router()
const sql = require('mssql')

  router.get('/:codigo', async (req, res, next) => {
    const codigoVer = req.params.codigo
    const result =  await sql.query`update Usuarios set correoVerificado = 1 where codigoActivacion = ${codigoVer}`
    const verificacion = 'Felicidades su cuenta ha sido verificada!! Ya puede realizar el login desde cualquier dispositivo!!\n'+
    'Reinicie su aplicación en caso de tenerla abierta para poder ingresar con la cuenta verificada.\n\nGracias por utilizar nuestros servicios,\nATECA'
    res.send(verificacion)
  })

  
module.exports = router