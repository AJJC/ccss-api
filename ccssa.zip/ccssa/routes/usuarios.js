var express = require('express')
var router = express.Router()
const sql = require('mssql')


/* GET home page. */
router.get('/', async function (req, res, next) {
  const result = await sql.query`select * from Usuarios`
  res.json(result).end()
})

/* Insert Usuario */
router.post('/', async function (req, res, next) {
  const { nombre,cedula,apellidos,fechaNacimiento,correo,contraseña,id_rol,estado,codigoActivacion } = req.body
  const result = await sql.query`insert into Usuarios (nombre,cedula,apellidos,fechaNacimiento,correo,contraseña,id_rol,estado,codigoActivacion) 
  values (${nombre},${cedula},${apellidos},${fechaNacimiento},${correo},${contraseña},${id_rol},${estado},${codigoActivacion})`


var nodemailer = require('nodemailer')

let transporter = nodemailer.createTransport({
  service: 'gmail',
  secure: false,
  port: 25,
  auth: {
      user: 'atecaccss2019@gmail.com',
      pass: 'aljica98'
  },
  tls:{
    rejectUnauthorized: false
  }
})

let HelperOptions = {
  from: '"ATECA" <atecaccss2019@gmail.com',
  to: correo,
  subject: 'Verificación del Correo',
  text: 'Saludos '+nombre+',\nUsted acaba de registrarse desde la aplicacion móvil de ATECA, para verificar su correo ingrese al siguiente link: '+
        'http://138.68.55.79/verificacion/'+codigoActivacion+'\nLuego de verificarse, reinicie su aplicación en caso de tenerla abierta\n'+
        'e inicie sesión.\n\nGracias por utilizar nuestros servicios, favor no responder este correo \nATECA'
}

transporter.sendMail(HelperOptions, (error,info) => {
  if(error){
    return console.log(error)
  }
  console.log("The message was sent")
  console.log(info)
})


  res.json(result).end()
})

/* Update Usuarios */
router.put('/', async (req, res, next) => {
    const { nombre,cedula,apellidos,fechaNacimiento,correo,id,estado } = req.body
  
    /*const stanza = [] // Campos a actualizar
    Object.keys(usuario).forEach(key => {
      stanza.push(`${key} = '${usuario[key]}'`)
    })
  console.log(stanza)*/
  const query = `update Usuarios set nombre = '${nombre}',cedula = '${cedula}',apellidos = '${apellidos}',fechaNacimiento = '${fechaNacimiento}',
                correo = '${correo}', estado = '${estado}' where ID_usuario = ${id}`
  console.log(query)
    const result = await sql.query(query)


    var nodemailer = require('nodemailer')

let transporter = nodemailer.createTransport({
  service: 'gmail',
  secure: false,
  port: 25,
  auth: {
      user: 'atecaccss2019@gmail.com',
      pass: 'aljica98'
  },
  tls:{
    rejectUnauthorized: false
  }
})

let HelperOptions = {
  from: '"ATECA" <atecaccss2019@gmail.com',
  to: correo,
  subject: 'Actualización de Información de la Cuenta',
  text: 'Saludos '+nombre+',\n Se acaba de actualizar su información en la aplicacion móvil de ATECA, en caso de no haber sido el que realizó '+
        'los cambios en la cuenta, contáctese con las oficinas de la C.C.S.S.\nInformación de la cuenta:\nNombre: '+nombre+'\nApellidos: '+apellidos+
        '\nCedula: '+cedula+'\nFecha de Nacimiento: '+fechaNacimiento+'\nCorreo: '+correo+'\nEstado: '+estado+'\n\nGracias por utilizar nuestros servicios,'+
        ' favor no responder este correo\nATECA'
}

transporter.sendMail(HelperOptions, (error,info) => {
  if(error){
    return console.log(error)
  }
  console.log("The message was sent")
  console.log(info)
})


    res.json(result).end()
  })





module.exports = router